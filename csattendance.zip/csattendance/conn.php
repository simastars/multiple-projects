<?php
define("host", "localhost");
define("username", "root");
define("password", "");
define("db", "attendance");
$conn = new Mysqli(host, username, password, db);

if(!$conn){
    die($conn->error);
}

?>