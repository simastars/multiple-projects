<?php
require 'conn.php';
if (isset($_POST['regnum']) && !empty($_POST['regnum'])) {
    $regnum = $_POST['regnum'];
    $rand = sha1(time() + rand());


    $randvalue = substr($rand, rand(0, 5), rand(5, 10));
    $querycheck = "SELECT * FROM studentdetail WHERE regnum='$regnum'";
    $queryres = $conn->query($querycheck);
    if ($queryres) {
        if ($queryres->num_rows > 0) {
            echo '<br>';
            $sql = "INSERT INTO token VALUE('','$randvalue','$regnum','yes')";
            $query = $conn->query($sql);

            if ($query) {
                ?>
                <script src="jquery.js" type="text/javascript"></script>
                <script src="sweetalert.min.js" type="text/javascript"></script>
                <script>
                    swal("success", "Token Has Been Generated Successfully", "success");
                    setTimeout(function () {
                        window.location.href = './index.php';
                    }, 3000)
                </script>
                <?php
            } else {
                echo $conn->error;
            }
        } else {
            echo "<br>";
            ?>
            <script src="jquery.js" type="text/javascript"></script>
            <script src="sweetalert.min.js" type="text/javascript"></script>
            <script>
                swal("error", "No record found for the given Matric Number", "error");
                setTimeout(function () {
                    window.location.href = './index.php';
                }, 3000)

            </script>
            <?php
        }
    } else {
        echo $conn->error();
    }
}
?>

<link href="Semantic-UI-CSS/semantic.min.css" rel="stylesheet" type="text/css"/>
<div class="ui container">
    <center>
        <form class="ui form" method="POST" action="">
            <input type="text" name="regnum" placeholder="Matric Number"/>
            <input type="submit" value="Generate" class="ui green button"/>
        </form>
    </center>
</div>