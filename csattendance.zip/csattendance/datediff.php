<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$date  = date("h:i:m");
date_interval_create_from_date_string("06:03:3");
//echo strtotime("now")."<br>";
//echo strtotime("06:03:3");

print_r(gettimeofday());