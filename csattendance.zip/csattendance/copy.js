
alert("hello")






$.ajax({
                        url: "login.php",
                        method: "POST",
                        dataType: "text",
                        data: {regnum: matric, phone: phoneNo, password: passwordN},
                        success: function (res) {
                            if (res === "ok") {
                                swal("success", "You are now Logged in Kindly record your attendance for this class", "success")
                                $(".attended").removeAttr("disabled");
                                $(".regnum").attr("disabled", "true");
                            } else {
                                alert(res);
                            }
                        }
                    })
    

