


<?php
require 'UserInfo.php';
$in = new UserInfo();

echo $in->get_device()."<br>";
echo $in->get_browser()."<br>";
echo $in->get_os()."<br>";
echo $in->get_ip();

?>