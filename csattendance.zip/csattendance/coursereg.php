<?php 

if(isset($_POST['empid'], $_POST['lectname'], $_POST['coursecode'])){
    require 'conn.php';
    $empid = $_POST['empid'];
    $lectname = $_POST['lectname'];
    $coursecode = $_POST['coursecode'];
    $coursetitle = $_POST['coursetitle'];
    $level = $_POST['level'];
    
    $sql = "INSERT INTO coursereg VALUES('','$empid','$lectname','$coursecode','$coursetitle', '$level')";
    $query = $conn->query($sql);
    if($query){
        echo "success";
    }else{
        echo $conn->error;
    }

}
?>
<link href="Semantic-UI-CSS/semantic.min.css" rel="stylesheet" type="text/css"/>
<div class="ui container">
    <form class="ui form" method="POST">
        <input type="text" name="empid" placeholder="Staff ID" required/><br>
        <input type="text" name="lectname" placeholder="Lecturer Name" required/><br>
        <input  type="text" name="coursecode" placeholder="Course Code" required/><br>
        <input type="text" name="coursetitle" placeholder="Course Title" required/><br>
        <select name="level" required>
            <option>Level</option>
            <option value="100L">100L</option>
            <option value="200L">200L</option>
            <option value="300L">300L</option>
            <option value="400L">400L</option>
            <option value="500L">500L</option>
        </select><br><br>
        <input type="submit" value="Add" class="ui olive button"/>
    </form>
</div>