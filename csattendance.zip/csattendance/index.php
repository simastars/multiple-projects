
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script src="jquery.js" type="text/javascript"></script>
        <link href="jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <script src="jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
        <link href="Semantic-UI-CSS/semantic.min.css" rel="stylesheet" type="text/css"/>
        <link href="homeStyle.css" rel="stylesheet" type="text/css"/>
        <script src="sweetalert.min.js" type="text/javascript"></script>
    </head>

    <?php
    require("conn.php ");
    require 'UserInfo.php';

    if (isset($_POST['regnum'], $_POST['phone'], $_POST['password'])) {

        $in = new UserInfo();
        $device = $in->get_device();
        $ipaddress = $in->get_ip();
        $operatingsystem = $in->get_os();


        $regnum = $_POST['regnum'];
        $phone = $_POST['phone'];
        $password = $_POST['password'];

        $sqlcheck = "SELECT * FROM studentdetail WHERE phoneNo='$phone' AND regnum='$regnum'";
        $querycheck = $conn->query($sqlcheck);
        if ($querycheck->num_rows > 0) {
            echo "<center><h3 color='red'>You have already register kindly login<h3></center>";
            ?>
            <script>
                swal("Error", "You have already register as it is done once, kindly login", "error");
            </script>
            <?php
        } else {
            $time = time();
            $sql = "INSERT INTO studentdetail VALUE('','$regnum','$phone','$password','$ipaddress','$operatingsystem','$time')";
            $query = $conn->query($sql);
            $date = date("M:D:Y h:m:s", time());
            $sqlfirstattend = "INSERT INTO classattendance VALUE('','$regnum','$date','')";
            $queryattend = $conn->query($sqlfirstattend);


            setcookie("phone", $phone, time() + 60);
            setcookie("password", $password, time() + 60);
            setcookie("ip", "$ipaddress", time() + 60);

            $inserttime = "INSERT INTO timecheck VALUES ('','$regnum', '')";
            $conn->query($inserttime);

            $phonecookie = $_COOKIE['phone'];


            if ($conn->affected_rows > 0) {
                ?>
                <script>
                    swal("success", "You have successfully registered for the attendance, kindly login to record your attendance", "success");
                    window.location.href = "index.php";
                </script>
                <?php
            } else {
                echo $conn->error;
            }
        }
    }
    ?>



    <body id="body">
        <div class="ui container" style="margin-top: 20px">
            <div class="ui grid">
                <div class="row">
                    <div class="ui nine wide column heading">
                        <div class="ui header" style="">
                            <h2 id="h1">Welcome to Computer Science Attendance System</h2>
                            <h4 id="h2">Ahmadu Bello University Zaria</h4>
                        </div>
                        <div class="ui green segment attend">
                            <h4 style="text-align: center">Click Here to record this class attendance</h4>
                            <center><button class="ui teal basic button attended" ><img src="./img/download.jpg" height="50px" width="120px" alt="you have to login before taking attendance"/></button></center>
                            <center><span>You have to login before it allows you to<br>record your attendance</span></center>
                        </div>
                        <h2>How to Use</h2>
                        <ul>
                            <li>Register (it is done once)</li>
                            <li>Supply your Matric Number and Click Login (for every course)</li>
                            <li>Once you are Logged In Click on (Everyday Count Button) to record your daily attendance</li>
                        </ul>
                        <h2>Having Trouble ? Follow the following Steps</h2>
                        <ol>
                            <li>if you are logged out (it is showing you re-register again)</li>
                            <ul><li>Go to the Lecturer and collect your Token</li>
                                <li>Click on (Already Register button)</li>
                                <li>Supply the token given to you and the other Details required</li>
                                <li>click on submit</li></ul>
                        </ol>
                    </div>
                    <div class="ui seven wide column">
                        <h2>Login to Record your Attendance for <?php if(isset($_COOKIE['coursetitle']) && !empty($_COOKIE['coursetitle'])){ echo "<u>".strtoupper($_COOKIE['coursetitle'])."</u>";}?></h2>
                        <div class="ui content">
                            <form class="ui form" method="POST" action="">
                                <input type="hidden" class="hidden" value="<?php echo $_COOKIE['phone']; ?>"/>
                                <input type="hidden" class="password" value="<?php echo $_COOKIE['password']; ?>"/>
                                <input type="text" name="regnum" placeholder="Matric Number" class="regnum" id="matric" required/><br><br>
                                <div id="hide">
                                    <input type="password" name="password" placeholder="12345678" class="pass" id="password"/><br><br>
                                    <input type="tel" name="phone" placeholder="phone number" class="phone" id="phone"/><br><br>
                                </div>
                                <center><input type="submit" name="register" value="Register" class="ui massive basic olive button reg"/></center>
                            </form>
                            <br><br>
                            <center><button class="ui red massive  button login">Login</button></center><br/><br/>
                            <center><button class="ui blue basic button" id="trouble">Already Register but having trouble logging in ? click here</button></center>
                        </div>

                    </div>
                    <div class="popup" title ="Your Token & Details" >
                        <ul>
                            <li><p><b>You have to go to the lecturer to get your Token</b></p></li>
                        </ul>
                        <form class="ui inverted form" method="POST" action="existinguser.php">
                            <input type="text" name="tokent" placeholder="Your Token" /><br><br />
                            <input type="text" name="regnumt" placeholder="Matric Number" /><br><br>
                            <input type="tel" name="phonet" placeholder="phone Number" /><br><br>
                            <input type="password" name="passwordt" placeholder="password" /><br><br>
                            <input type="submit" class="ui green button trouble" id="troublesubmit"  value="Submit" />
                        </form>
                    </div>
                </div>
                <input type="hidden" class="allowattendance" value="<?php echo $_COOKIE['allowattendance'] ?>"/>
                <input type="hidden" class="regnumcookie" value="<?php echo $_COOKIE['regnumcookie'] ?>"/>
                <input type="hidden" class="disableattendance" value="<?php echo $_COOKIE['disableattendance'] ?>"/>
                <?php
                if (isset($_COOKIE['disableattendance']) && !empty($_COOKIE['disableattendance'])) {
                    define("disableattendance", $_COOKIE['disableattendance']);
                }
                ?>
                <input type="hidden" value="<?php echo disableattendance; ?>" class="disableattendanceconst"/>

            </div>
        </div>
    </body>
</html>
<script>
    $(document).ready(function () {
        $(".attended").attr("disabled", "true");
        $(".popup").dialog({
            autoOpen: false,
            width: 400
        });

        var allowattendance = $('.allowattendance').val();

        if (allowattendance.length === 5) {
            $(".attended").removeAttr("disabled");
            $(".regnum").attr("disabled", "true");
        }

        var cookie = $(".hidden").val();
        if (cookie.length <= 14) {
            $(".pass").attr("disabled", "disabled");
            $(".phone").attr("disabled", "disabled");
            $(".pass").remove();
            $(".phone").remove();
            $(".reg").attr("disabled", "true");

        } else {
            $(".pass").removeAttr("disbaled");
            $(".phone").removeAttr("disabled");
            $(".reg").removeAttr("disabled");
            $(".login").attr("disabled", "true");
        }

        $(".login").click(function () {
            var regnum = $(".regnum").val();
            var phone = $(".hidden").val();
            var password = $(".password").val();
            if (regnum === "" || phone === "" || password === "") {
                swal("Error", "All fields are required");
            } else {
                $.ajax({
                    url: "login.php",
                    method: "POST",
                    dataType: "text",
                    data: {regnum: regnum, phone: phone, password: password},
                    success: function (res) {
                        if (res === "ok") {
                            swal("success", "You are now Logged in Kindly record your attendance for this class", "success");
                            $(".attended").removeAttr("disabled");
                            $(".regnum").attr("disabled", "true");
                        } else {
                            alert(res);
                        }
                    }
                })
            }

        })
        setInterval(function () {
            var disableattendance = $(".disableattendanceconst").val();
            if (disableattendance.length <= 7) {
                $(".attended").attr("disabled", "disabled");
            }
        }, 1000)

        setInterval(function () {
            window.location.href = "index.php";
        }, 30000)

        $(".attended").click(function () {


            var regnumcookie = $(".regnumcookie").val();

            var regnum = $(".regnum").val();
            var phone = $(".hidden").val();
            var password = $(".password").val();

            $.ajax({
                url: "recordattendance.php",
                method: "POST",
                dataType: "text",
                data: {regnum: regnum, phone: phone, password: password},
                success: function (res) {
                    alert(res)
                }
            })


        })
        $("#trouble").click(function () {
            $(".popup").dialog("open")
        })
//        $(".trouble").click(function () {
//
//            var regnum = $(".regnumt").val();
//            var token = $(".tokent").val();
//            var phone = $(".phonet").val();
//            var password =$(".passwordt");

//            $.ajax({
//                url: "hello.php",
//                method: "POST",
//                dataType: "text",
//                data: {regnum: regnum, token:token, phone:phone,password:password},
//                success: function (res) {
//                    alert(res);
//                }
//            })
//        })

    })
</script>