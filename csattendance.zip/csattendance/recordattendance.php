<?php

require 'conn.php';

if (isset($_COOKIE['duplicateattend'])) {
    echo "You already Done your attendance for the Class";
} else {
    setcookie("duplicateattend","attended", time()+1800);
    if (isset($_POST['regnum'])) {
        $regnum = $_POST['regnum'];
        $phone = $_POST['phone'];
        $password = $_POST['password'];

//    echo $date  = date("h:i:m - D :F : Y");

        $sqlselect = "SELECT * FROM studentdetail WHERE regnum='$regnum'";
        if ($query = $conn->query($sqlselect)) {
            $row = $query->fetch_assoc();
//        $disableattendance = setcookie("disableattendance", "disable", time()+40);
//        $logintime =  $row['time'];
//        
//        $now = time();
//        
//        $compare = $logintime - $now;


            echo "yes";
            $regnum = $row['regnum'];
            $sqlattend = "SELECT * FROM classattendance WHERE studentRegNo ='$regnum'";
            $queryattend = $conn->query($sqlattend);
            $assocattend = $queryattend->fetch_assoc();
            $dateandtime = $assocattend['DateAndTime'];
            $numberofattendance = $assocattend['numberOfAttend'];

            $numofattend = $numberofattendance + 1;
            $date = date("h:i:m - D :F : Y");
            $sqlupdateattend = "UPDATE classattendance SET numberOfAttend='$numofattend', DateAndTime='$date' WHERE studentRegNo='$regnum'";
            $queryupdateattend = $conn->query($sqlupdateattend);

            if ($queryupdateattend) {
                echo "success";
            } else {
                echo $conn->error;
            }
        }
    }
}

