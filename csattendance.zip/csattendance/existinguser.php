<?php

if (isset($_POST['tokent'])) {

    require 'conn.php';
    $regnum = $_POST['regnumt'];
    $phone = $_POST['phonet'];
    $password = $_POST['passwordt'];
    $token = $_POST['tokent'];


    $sqlStudent = "SELECT * FROM studentdetail WHERE regnum='$regnum' AND phoneNo='$phone'";
    $queryresult = $conn->query($sqlStudent);


    if ($queryresult) {
        if ($queryresult->num_rows > 0) {

            $record = $queryresult->fetch_assoc();

            $sql = "SELECT * FROM token WHERE regnum='$regnum' AND token='$token' AND active='yes'";
            $query = $conn->query($sql);

            if (mysqli_num_rows($query) > 0) {

                $sqlupdate = "UPDATE token SET active='no' WHERE regnum='$regnum' AND token='$token'";
                $conn->query($sqlupdate);

                setcookie("matricnum", $record['regnum'], time() + 1000);
                setcookie("password", $record['password'], time() + 1000);
                setcookie("phone", $record['phoneNo'], time() + 1000);
                setcookie("allowattendance", "allow", time()+60);
                setcookie("regnumcookie", $regnum, time() + 120);
                ?>
                <script src="jquery.js" type="text/javascript"></script>
                <script src="sweetalert.min.js" type="text/javascript"></script>
                <script>
                    alert("Success");
                    window.location.href = "index.php";
                </script>
                <?php

            } else {
                ?>
                <script>
                    alert("Sorry either this record does not Exist, or the token has been expired");
                    window.location.href = "index.php";
                </script>
                <?php

            }
        } else {
            echo 'Sorry No record found for user ' . $regnum;
        }
    } else {
        echo $conn->error;
    }
}























