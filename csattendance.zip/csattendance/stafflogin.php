<?php

if(isset($_POST['staffid'], $_POST['coursecode'])){
    require 'conn.php';
    $staffid = $_POST['staffid'];
    $coursecode = $_POST['coursecode'];
    
    
    $sql = "SELECT * FROM coursereg WHERE empid='$staffid' AND coursecode='$coursecode'";
    $query = $conn->query($sql);
    if($query){
        $row = $query->fetch_assoc();
        var_dump($row);
        $lectname = $row['lectname'];
        $coursetitle = $row['coursetitle'];
        echo $lectname;
        setcookie("lectlogin", "$lectname", time()+1800);
        setcookie("coursetitle", "$coursetitle", time()+1800);
        
    }else{
        echo $conn->error;
    }

}


?>
<script src="jquery.js" type="text/javascript"></script>
<link href="Semantic-UI-CSS/semantic.min.css" rel="stylesheet" type="text/css"/>
<script src="sweetalert.min.js" type="text/javascript"></script>
<form class="ui form" method="POST">
    <input type="text" name="staffid" placeholder="Staff ID" required/><br><br/>
    <input type="text" name="coursecode" placeholder="coursecode" required/><br><br>
    <input type="submit" name="Login" class="ui green basic button"/>
</form>