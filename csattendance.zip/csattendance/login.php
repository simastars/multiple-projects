<?php
if (isset($_POST['regnum'], $_POST['phone'], $_POST['password'])) {
    require 'conn.php';
    $regnum = $_POST['regnum'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM studentdetail WHERE regnum='$regnum ' AND phoneNo='$phone' AND password='$password'";
    $query = $conn->query($sql);
    if ($query) {
        $date = time();
        setcookie("logintime", $date, time()+1500);
        if ($query->num_rows > 0) {
            $sqldate = "UPDATE studentdetail SET time='$date' WHERE regnum='$regnum'";
            $querydate = $conn->query($sqldate);
            setcookie("regnumcookie", $regnum, time() + 120);
            echo "ok";
        } else {
            echo 'No record match with '.$regnum."\n login with the Matric Number you first register with";
        }
    } else {
        echo $conn->error;
    }
}
?>