<?php 

if (isset($_POST['seen'])) {
    require 'dbpdo.php';
    $id = $_COOKIE['userid'];
    $seen = $_POST['seen'];
    $level = '';
    $query = "SELECT * FROM patientrecord WHERE labtest='$seen' AND id='$id'";
    $result = $conn->query($query);
    if ($result) {
        if ($result->num_rows > 0) {
            $record = $result->fetch_assoc();
            $malarialevel = $record['malarialevel'];
            if ($malarialevel >= 11) {
                echo "You have been Examined, but please visit a Lab for Malaria Test and bring back the result";
            } elseif ($malarialevel <= 10) {
                echo "Please see a doctor, the system didn't diagnosed you with malaria, thank you";
            }
        }else{
            echo "You have been Examined, but please visit a Lab for Malaria Test and bring back the result ";
        }
    } else {
        echo $conn->error;
    }
}
?>








