<?php ?>
<html>
    <head>
        <title>Registration</title>
        <style>
            body{
                margin: 0px;
                padding: 0px;
            }
            #header{
                background-image: url("./pics/msalone.jpg");
                height: 25%;
                background-repeat: no-repeat;
                background-position: center;
                margin-top: 10px;
            }
            h1{
                text-align: center;
                margin-top: 40px;
                color: mediumblue;
            }
        </style>
        <link href="semantic-ui/semantic.min.css" rel="stylesheet" type="text/css"/>

    </head>
    <body>
        <div class="ui container">
            <div class="ui header" id="header">
                <h1>Welcome to Expert System for Diagnosing Malaria</h1>
            </div>
            <div class="ui inverted segment">
                <div class="ui grid">
                    <div class="ui six wide column inverted segment">
                        <h1>Description</h1>
                        <p style="font-size: 24px; color: blue">
                            Malaria, a potentially fatal blood disease, is caused by a parasite that is transmitted to human and animal hosts through the Anopheles mosquitoes.
                        </p><p style="font-size: 24px; color: blue">An expert system  for malaria diagnostics  is  a system  that  helps  to determine the extent of malaria parasites presence in human body based on answers supplied. 
                        </p>
                    </div>
                    <div class="ui six wide column">
                        <h1>Register Here</h1>
                        <form method="POST" action="register.php" class="ui form" style="background-image:url('./pics/msgreen.jpg')">
                            <input type="text" name="fname" placeholder="First Name" required><br><br/>
                            <input type="text" name="lname" placeholder="Last Name" required/><br/><br/>
                            <input type="text" name="age" placeholder="Age" required/><br/><br/>
                            <input type="tel" name="phone" placeholder="+2348169895827" required/><br/><br/>
                            <input type="email" name="email" placeholder="example@example.com" required/><br/><br/>
                            <input type="password" name="password" placeholder="*****" required/><br/><br/>
                            <input type="text" name="address" placeholder="Addree" required/><br/><br/>
                            <input type="text" name="nkname" placeholder="Next of Kin Full Name" required/><br/><br/>
                            <input type="tel" name="nkphone" placeholder="next of kin Phone Number"/><br/><br/>
                            <input type="submit" name="kinphone" value="Register" name="register" class="ui secondary button"/>
                        </form>
                    </div>
                    <div class="ui four wide column">
                        <h1>Login Here</h1>
                        <form method="POST" action="login.php" class="ui form" style="background-image:url('./pics/mscross.jpg')">
                            <input type="text" name="email" placeholder="Email" required/><br/><br/>
                            <input type="password" name="pass" placeholder="****" required/><br/><br>
                            <input type="submit" name="login" value="Login" class="ui primary button"/>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
