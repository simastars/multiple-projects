<?php

if (isset($_POST['seen']))
{
    require 'dbpdo.php';
    $id = $_COOKIE['userid'];
    $seen = $_POST['seen'];
    $level = '';
    $query = "UPDATE patientrecord SET labtest='$seen' WHERE id='$id'";
    $result = $conn->query($query);

    if ($result)
    {
        if ($result == 1)
        {
            $query = "SELECT * FROM patientrecord WHERE labtest='$seen' AND id='$id'";
            $result = $conn->query($query);
            $record = $result->fetch_assoc();
            if ($record > 0)
            {
                $malarialevel = $record['malarialevel'];
                if ($malarialevel >= 11)
                {
                    echo "Get a prescription from here or visit a doctor";
                }
                elseif ($malarialevel <= 10)
                {
                    echo "Please see a doctor, the system didn't diagnosed you with malaria, thank you";
                }
            }
            else
            {
                
            }
        }
    }
    else
    {
        echo $conn->error;
    }
}
?>


















