<?php
if (isset($_COOKIE['userid']) && !empty($_COOKIE['userid']))
{
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8">
            <script src="jquery.js" type="text/javascript"></script>
            <script src="sweetalert.min.js" type="text/javascript"></script>
            <link href="jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
            <script src="jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
            <link href="semantic-ui/semantic.min.css" rel="stylesheet" type="text/css"/>
            <title></title>
        </head>
        <body style="background: url('./pics/header.jpg'); background-repeat: no-repeat; background-attachment: fixed;background-position: center center;
              background-size: cover; height: 200px">
            <div class="ui container">
                <div class="ui header" >
                    <center><h1 style="color: green; margin-top: 25px">Welcome to Expert System for Diagnosing Malaria</h1></center>
                </div>
                <div class="ui grid">
                    <div class="ui nine wide column">
                        <div class="ui menu">
                            <div class="item"><a class="ui green button" href="actions.php">Register</a></div>
                            <div class="item" disabled="true"><a class="ui button" href="home.php">Check Me</a></div>
                            <div class="item"><a class="ui yellow button" href="actions.php">Login</a></div><br>
                            <div class="item"><a class="ui red button pres">Get Prescription</a></div>
                            <div><button id="checkresult" class="ui olive button" data-id="<?php echo $_COOKIE['userid'] ?>">Lab Result</button></div>

                        </div>
                        <div id="result" style="font-size: 24px; color: blue">
                            <ol>
                                <li>Click on check me and answer the provided questions</li>
                                <li>Click on Lab test to present</li>
                                <li>Click on Get prescription to get a prescription</li>
                            </ol>
                        </div>
                    </div>
                    <div class="ui seven wide column inverted segment">
                        <h1>Description</h1>
                        <p style="font-size: 24px; color: blue">
                            Malaria, a potentially fatal blood disease, is caused by a parasite that is transmitted to human and animal hosts through the Anopheles mosquitoes.
                        </p><p style="font-size: 24px; color: blue">An expert system  for malaria diagnostics  is  a system  that  helps  to determine the extent of malaria parasites presence in human body based on answers supplied. 
                        </p>
                        
                    </div>
                </div>
            </div>
        </body>
    </html>
    <?php
}
else
{
    header("location: actions.php");
}
?>


<script>
    $(document).ready(function () {
        $("#checkresult").click(function () {
            if (confirm("Is Malaria Parasite present in your Lab test?\n Click OK if Yes or CANCEL for No")) {
                var userid = $(this).data("id");
                var seen = "MP Seen";
                $.ajax({
                    url: "checkresult.php",
                    method: "POST",
                    data: {seen:seen},
                    dataType: "text",
                    beforeSend: function () {
                        $("#checkresult").text("Fetching...");
                        $("#checkresult").removeClass("ui olive button");
                        $("#checkresult").addClass("ui red button");
                    },
                    success: function (data) {
                        $("#checkresult").text("Done");
                        $("#checkresult").removeClass("ui red button");
                        $("#checkresult").addClass("ui green button");
                        $("#checkrsult").attr("disabled", "disabled");
                        swal('infor', data)
                    }
                })
            } else {
                swal("Infor", "you have no malaria, thank you", "error");
            }
        })
        $(".pres").click(function () {
            var userid = $(this).data("id");
            var seen = "MP Seen";
            $.ajax({
                url: "getprescription.php",
                method: "POST",
                data: {userid: userid,seen:seen},
                dataType: "text",
                beforeSend: function () {
                    $(".pres").text("Fetching...");
                    $(".pres").removeClass("ui red button");
                    $(".pres").addClass("ui yellow button");
                },
                success: function (data) {
                    $(".pres").text("Done");
                    $(".pres").removeClass("ui yellow button");
                    $(".pres").addClass("ui green button");
                    $(".pres").attr("disabled", "disabled");
                    $("#result").html(data);
                }
            })
        })
    })
</script>
