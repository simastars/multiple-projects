<?php

if (isset($_POST['fname'], $_POST['lname'])) {
    require 'dbpdo.php';
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $age = $_POST['age'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $nkname = $_POST['nkname'];
    $nkphone = $_POST['phone'];
    $password = md5($_POST['password']);
    $query = "INSERT INTO patientrecord VALUES('','$fname','$lname','$age','$phone','$email','$password','$address','$nkname', '$nkphone','','')";
    if ($result = $conn->query($query)) {
        ?>
        <script src="jquery.js" type="text/javascript"></script>
        <script src="sweetalert.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                swal('Success', 'You have Successfully Registered, please Login to Enjoy', 'success');
                setTimeout(function(){
                    window.location.href = './actions.php';
                }, 4000)
                
            })
        </script>
        <?php

    } else {
        ?>
        <script src="jquery.js" type="text/javascript"></script>
        <script src="sweetalert.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                swal('error', 'Ooops there was an error, please try again later', 'error');
                window.location.href = './actions.php';
            })
        </script>
        <?php

    }
}
?>
