<?php

$conn = new mysqli("localhost","root","","expertsystem");

if(!$conn){
    die($conn->error);
}