<?php

if (isset($_POST['seen'])) {
    require 'dbpdo.php';
    $id = $_COOKIE['userid'];
    $seen = $_POST['seen'];
    $level = '';
    $query = "SELECT * FROM patientrecord WHERE id='$id' and labtest='$seen'";
    $result = $conn->query($query);
    if ($result) {
        if ($result->num_rows > 0) {
            $record = $result->fetch_assoc();
            if($record['age']>=35){
                $state = "Adult";
            }elseif($record['age']>=18){
                $state = "Teenage";
            }elseif ($record['age']>=5) {
                $state = "Child";
            }elseif($record['age']>=1){
                $state = "Neonet";
            }else{
                $state = "Out of determination";
            }
            $sqlpres = "SELECT * FROM prescription WHERE state='$state'";
            $resultpres = $conn->query($sqlpres);
            if($resultpres){
                $recordpres = $resultpres->fetch_assoc();
                echo "<strong>".$recordpres['drugs']."<br><br>".$recordpres['advice']."</strong>";
            }else{
                echo $conn->error;
            }
        }else{
            echo "Please supply your lab result before getting prescription";
        }
    } else {
        echo $conn->error;
    }
}































