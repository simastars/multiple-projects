how to use the software

1.extract the zip file 

2.create database with the name (expertsystem)

3.import expertsytem.sql file found inthe zip file

4.visit localhost/expertsystem in your browser after starting your server

5.register or login with test@expertsystem.com with password 1234



enjoy!