<?php
$userid = $_COOKIE['userid'];

if ($_POST['time'])
{
    require 'dbconn.php';
    $sqlselect = "SELECT * FROM studentdetail WHERE sn='$userid'";
    $resultselect = $conn->query($sqlselect);
    $row = $resultselect->fetch_assoc();
    if ($row['exptime'] >= 1)
    {
        $timervalue = $row['exptime'] - 1;
        $sql = "UPDATE studentdetail SET exptime='$timervalue' WHERE sn='$userid'";
        $result = $conn->query($sql);
        if ($result)
        {
            
        }
        else
        {
            echo $conn->error;
        }
    }else{
      die("Your time has ended");
    }
}
?>






