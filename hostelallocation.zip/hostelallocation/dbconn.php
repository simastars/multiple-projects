<?php

define("host", "localhost");
define("user", "root");
define("password", "");
define("database", "hostel");

$conn = new mysqli(host, user, password, database);

if(!$conn){
    die($conn->error);
}

?>

