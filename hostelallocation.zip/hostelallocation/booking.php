<?php
require 'dbconn.php';
$userid = $_COOKIE['userid'];
$sql = "SELECT * FROM studentdetail WHERE sn='$userid'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
if ($row['hostel'] == "No")
{
    ?>
    <script src="jquery.js" type="text/javascript"></script>
    <script>

        alert("Sorry you wont be able to room for now kindly visit later");
        window.location.href = 'index.php';
    </script>

    <?php
}
else
{
    $sql = "SELECT * FROM studentdetail WHERE sn='$userid'";
    $result = $conn->query($sql);
    if ($result)
    {
        if ($result->num_rows > 0)
        {
            $row = $result->fetch_assoc();
            ?>
            <input type="hidden" value="<?php echo $row['sn']; ?>" id="userid"/>
            <?php
        }
        else
        {
            header("location: signin.php");
        }
    }
    else
    {
        echo $conn->error;
    }
}
?>
<html>
    <head>
        <title>Book A Room</title>
    </head>
    <body>
        <p id="demo"></p>
        <button id="booknow">Book Now</button>
    </body>
</html>
<script src="jquery.js" type="text/javascript"></script>

<!-- Display the countdown timer in an element -->


<script>
    $(document).ready(function () {
        // Set the date we're counting down to     var countDownDate = new Date("Jan 5, 2021 15:37:25").getTime();
        var today = new Date();
        var tomorrow = today.setMinutes(today.getMinutes() + 120)
        //var usabletomorrow = tomorrow.setTime(tomorrow.getTime()+60);
        var countDownDate = new Date(tomorrow).getTime();
        // Update the count down every 1 second
        var x = setInterval(function ()

        {
            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Display the result in the element with id="demo"
            document.getElementById("demo").innerHTML = days + "d " + hours + "h "
                    + minutes + "m " + seconds + "s ";

            // If the count down is finished, write some text
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("demo").innerHTML = "EXPIRED";
                var status = "EXPIRED";
                if (status === "EXPIRED") {
                    var userid = $('#userid').val();
                    $.ajax({
                        url: "updatehostelstatus.php",
                        method: "POST",
                        dataType: "text",
                        data: {userid: userid},
                        success: function (data) {
                            alert(data);
                        }
                    })
                } else {

                }
            }

        }, 1000);

        $('#booknow').click(function () {
            var userid = $('#userid').val();
            $.ajax({
                url: "bookhostel.php",
                method: "POST",
                dataType: "text",
                data: {userid: userid},
                success: function (data) {
                    alert(data);
                }
            })
        })
    })

</script>

































































