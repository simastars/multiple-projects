<?php

require 'dbconn.php';
$value = 1;
$userid = $_COOKIE['userid'];


$sqlcheck = "SELECT * FROM allocation WHERE studentid='$userid'";
$resultcheck = $conn->query($sqlcheck);
if ($resultcheck->num_rows > 0)
{
    echo "Room is already assigned to you, kindly visit Hostel admin.";
}
else
{
    $sql = "SELECT * FROM rooms WHERE available>='$value'";
    $result = $conn->query($sql);
    if ($result)
    {
        IF ($result->num_rows > 0)
        {
            $room = $result->fetch_assoc();
            $roomnumber = $room['available'];
            $randroom = rand(1, $roomnumber);
            $hallname = $room['hall'];
            $sqlins = "INSERT INTO allocation VALUES('','$userid','$randroom','$hallname')";
            if ($resultbook = $conn->query($sqlins))
            {
                $decresevalue = $room['available'] - 1;
                $update = "UPDATE rooms SET available='$decresevalue'";
                if ($resultdecrease = $conn->query($update))
                {
                    $sqlallocate = "UPDATE studentdetail SET allocated='Yes' WHERE sn='$userid'";
                    $result = $conn->query($sqlallocate);
                    echo "Room have been assigned to you, kindly visit the hostel admin to collect receipt";
                }
                else
                {
                    echo $conn->error;
                }
            }
            else
            {
                echo $conn->error;
            }
        }
        else
        {
            echo 'no room is available';
        }
    }
}
?>


















