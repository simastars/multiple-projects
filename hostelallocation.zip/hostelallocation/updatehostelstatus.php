<?php
require 'dbconn.php';
if($_POST['userid']){
    $userid = $_POST['userid'];
    $sql = "UPDATE studentdetail SET hostel='No' WHERE sn='$userid'";
    $result = $conn->query($sql);
    if($result){
        echo "Sorry your permission to book hostel has been revoked";
    }else{
        echo $conn->error;
    }
}

?>
