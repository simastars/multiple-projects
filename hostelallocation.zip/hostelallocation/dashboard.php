<?php
require 'dbconn.php';
$userid = $_COOKIE['userid'];
if (isset($userid) && !empty($userid))
{
    $sqlavailabe = "SELECT * FROM rooms WHERE available>='1'";
    $result = $conn->query($sqlavailabe);
    if ($result->num_rows > 0)
    {
        $sqlaallocate = "SELECT * FROM allocation WHERE studentid='$userid'";
        $resultallocate = $conn->query($sqlaallocate);
        
        if ($resultallocate->num_rows == 0)
        {
            $sql = "SELECT * FROM studentdetail WHERE sn='$userid'";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
            if ($row['hostel'] == "No")
            {
                ?>
                <script src="jquery.js" type="text/javascript"></script>
                <script>
                    alert("Sorry you wont be able to book for room now, kindly visit later");
                    window.location.href = 'index.php';
                </script>

                <?php
            }
            else
            {
                $sql = "SELECT * FROM studentdetail WHERE sn='$userid'";
                $result = $conn->query($sql);
                if ($result)
                {
                    if ($result->num_rows > 0)
                    {
                        $row = $result->fetch_assoc();
                        $sqltimer = "SELECT * FROM studentdetail WHERE sn='$userid'";
                        $resulttimer = $conn->query($sqltimer);
                        $timer = $resulttimer->fetch_assoc();
                        ?>
                        <input type="hidden" value="<?php echo $timer['exptime']; ?>" id="timer"/>
                        <input type="hidden" value="<?php echo $row['sn']; ?>" id="userid"/>
                        <?php
                    }
                    else
                    {
                        header("location: signin.php");
                    }
                }
                else
                {
                    echo $conn->error;
                }
            }
        }else{
            die("you already booked");
        }
    }
    else
    {
        die("<center><div class='ui red circular segment'>"
                . "<h1>Sorry no Rooms Available</h1>"
                . "</div></center>");
    }
}
else
{
    ?>
    <script src="jquery.js" type="text/javascript"></script>
    <script>
        alert("You are Logged out, please Login");
        window.location.href = 'signin.php';
    </script>
    <?php
}
?>
<html>
    <head>
        <title>Book A Room</title>
        <link href="Semantic-UI-CSS-master/Semantic-UI-CSS-master/semantic.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="background-image: url('./img/bodybg.jpg'); background-repeat: repeat-x; background-position: center">
    <center>
        <div style="max-width: 200px" class="ui green segment">
            <p id="demo" class="ui circular red segment" style="border: 2px teal dotted; height: 100px"></p><br>
            <button id="booknow" class="ui green button">Book Now</button><br/><br/>
            <a href="./index.html" class="ui teal button">Home</a>
        </div>
    </center>
</body>
</html>
<script src="jquery.js" type="text/javascript"></script>

<!-- Display the countdown timer in an element -->
<script>
    $(document).ready(function () {
        // Set the date we're counting down to     var countDownDate = new Date("Jan 5, 2021 15:37:25").getTime();
        var timer = Number($('#timer').val());
        var today = new Date();
        var tomorrow = today.setMinutes(today.getMinutes() + timer);
        //var usabletomorrow = tomorrow.setTime(tomorrow.getTime()+60);
        var countDownDate = new Date(tomorrow).getTime();
        // Update the count down every 1 second
        var x = setInterval(function ()

        {
            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Display the result in the element with id="demo"
            document.getElementById("demo").innerHTML = days + "d " + hours + "h "
                    + minutes + "m " + seconds + "s ";

            //update timer in database


            // If the count down is finished, write some text
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("demo").innerHTML = "EXPIRED";
                var status = "EXPIRED";
                if (status === "EXPIRED") {
                    var userid = $('#userid').val();
                    $.ajax({
                        url: "updatehostelstatus.php",
                        method: "POST",
                        dataType: "text",
                        data: {userid: userid},
                        success: function (data) {
                            alert(data);
                        }
                    })
                } else {

                }
            }

        }, 1000);
        setTimeout(function () {
            var time = 1;
            $.ajax({
                url: "updatetimer.php",
                method: "POST",
                dataType: "text",
                data: {time: time},
                success: function (data) {

                }
            })
        }, 60000)


        $('#booknow').click(function () {
            var userid = $('#userid').val();
            $.ajax({
                url: "bookhostel.php",
                method: "POST",
                dataType: "text",
                data: {userid: userid},
                success: function (data) {
                    alert(data)
                }
            })
        })
    })

</script>



















































































