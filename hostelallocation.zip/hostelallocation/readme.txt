=================== Automated hostel allocation and booking system ====================
Please read this before using this software

FIRST*
1. The software is live and interacts with database. The host computer must have a running local server(WAMP or XAMPP) before it will work.
2. If you're using XAMPP, extract the files into the htdocs folder (it's always C:\xampp\htdocs)

If you're using WAMP, extract them to www folder (it's always C:\WAMP\www)

=============================================================

RUNNING THE APP

1. Put on your local server. 
2. Open your browser and go to phpmyadmin (it's always http://localhost/phpmyadmin) 
3. create database named (hostel)
3. Click on import then select the hostel.sql file which is in the main folder.
4. Go to homepage (http://localhost/hostelallocation)

LOGIN DETAILS
username-- muhdmuhd158@gmail.com
password-- 1234

