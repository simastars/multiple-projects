<html>

<head>
    <title>Register</title>
    <link href="Semantic-UI-CSS-master/Semantic-UI-CSS-master/semantic.min.css" rel="stylesheet" type="text/css"/>
    <script src="sweetalert.min.js" type="text/javascript"></script>
    <script src="jquery.js" type="text/javascript"></script>
</head>

<body>

<?php

if(isset($_POST['fname'], $_POST['lname'], $_POST['email'])){
    include('dbconn.php');
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $nkname = $_POST['nkname'];
    $nkphone = $_POST['nkphone'];
    $nkemail = $_POST['nkemail'];
    $nkaddress = $_POST['nkaddress'];
    $dept = $_POST['dept'];
    $level = $_POST['level'];
    
$sql = "INSERT INTO studentdetail VALUES('','$fname','$lname','$email','$phone','$password','$address','$nkname','$nkphone','$nkemail','$nkaddress','$dept', '$level','Yes', '120','No')";
$result = $conn->query($sql);
if($result){
 ?>
<script>
    alert("you have successfully register");
</script>
 <?php

}else{
    echo $conn->error;
}

}
?>


    <div class="ui container">
        <div class="ui grid">
            <div class="ui eleven wide column">
                <h1>Register</h1>
                <form class="ui form" method="POST">
                    <input type="text" name="fname" placeholder="First Name" required/><br><br>
                    <input type="text" name="lname" placeholder="Last Name" required/><br><br>
                    <input type="email" name="email" placeholder="example@example.com" required/><br><br>
                    <input type="tel" name="phone" placeholder="+2348169895827" required/><br><br>
                    <input type="password" name="password" placeholder="password" required/><br><br>
                    <input type="text" name="address" placeholder="address" required/><br><br>
                    <input type="text" name="nkname" placeholder="Next of Kin full name" required /><br><br>
                    <input type="tel" name="nkphone" placeholder="Next of kin Phone No." required/><br><br>
                    <input type="email" name="nkemail" placeholder="Next of Email" required/><br><br>
                    <input type="text" name="nkaddress" placeholder="NK Address" required/><br><br>
                    <input type="text" name="dept" placeholder="Department" required/><br><br>
                    <input type="text" name="level" placeholder="Level" required/><br><br>
                    <input type="submit" value="Register" name="submit" class="ui green button"/>
                </form>
            </div>
            <div class="ui five wide column">

            </div>
        </div>
    </div>
</body>

</html>













