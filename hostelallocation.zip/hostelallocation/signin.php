<?php
require'dbconn.php';
if(isset($_POST['email'], $_POST['password'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql ="SELECT * FROM studentdetail WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);
    if($result)
    {
        if($result->num_rows>0){
        $row = $result->fetch_object();
        setcookie('user', $row->email, time()+380);
        setcookie('userid', $row->sn, time()+380);
        header("location: dashboard.php");
        }else{
            die("Records not Found");
        }
    }
    else
    {
        echo $conn->error;
    }
}

?>


<html>
    <head>
        <title>Login</title>
        <link href="Semantic-UI-CSS-master/Semantic-UI-CSS-master/semantic.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div class="ui container">
            <div class="ui grid ">
                <div class="row">
                
                <div class="ui eight wide column">
                    <h1 align="center">Login</h1>
                    <form class="ui form" action="" method="POST">
                        <input type="text" name="email" placeholder="Email/Phone"/><br><br>
                        <input type="password" name="password" placeholder="password"/><br><br>
                        <input type="submit" value="Login" class="ui green button"/>
                    </form>
                </div>
                <div class="ui six wide column">
                    <h1></h1>
                    <img src="./img/homebanner.jpg" height="100%" wide="100%" >
                </div>
            </div>
</div>
        </div>
    </body>
</html>





